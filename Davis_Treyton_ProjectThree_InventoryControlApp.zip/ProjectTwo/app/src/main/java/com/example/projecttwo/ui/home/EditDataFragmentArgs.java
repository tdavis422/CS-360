package com.example.projecttwo.ui.home;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.lifecycle.SavedStateHandle;
import androidx.navigation.NavArgs;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.HashMap;

public class EditDataFragmentArgs implements NavArgs {
  private final HashMap arguments = new HashMap();

  private EditDataFragmentArgs() {
  }

  @SuppressWarnings("unchecked")
  private EditDataFragmentArgs(HashMap argumentsMap) {
    this.arguments.putAll(argumentsMap);
  }

  @NonNull
  @SuppressWarnings("unchecked")
  public static EditDataFragmentArgs fromBundle(@NonNull Bundle bundle) {
    EditDataFragmentArgs __result = new EditDataFragmentArgs();
    bundle.setClassLoader(EditDataFragmentArgs.class.getClassLoader());
    if (bundle.containsKey("itemId")) {
      String itemId;
      itemId = bundle.getString("itemId");
      if (itemId == null) {
        throw new IllegalArgumentException("Argument \"itemId\" is marked as non-null but was passed a null value.");
      }
      __result.arguments.put("itemId", itemId);
    } else {
      throw new IllegalArgumentException("Required argument \"itemId\" is missing and does not have an android:defaultValue");
    }
    if (bundle.containsKey("itemCount")) {
      String itemCount;
      itemCount = bundle.getString("itemCount");
      if (itemCount == null) {
        throw new IllegalArgumentException("Argument \"itemCount\" is marked as non-null but was passed a null value.");
      }
      __result.arguments.put("itemCount", itemCount);
    } else {
      throw new IllegalArgumentException("Required argument \"itemCount\" is missing and does not have an android:defaultValue");
    }
    return __result;
  }

  @NonNull
  @SuppressWarnings("unchecked")
  public static EditDataFragmentArgs fromSavedStateHandle(
      @NonNull SavedStateHandle savedStateHandle) {
    EditDataFragmentArgs __result = new EditDataFragmentArgs();
    if (savedStateHandle.contains("itemId")) {
      String itemId;
      itemId = savedStateHandle.get("itemId");
      if (itemId == null) {
        throw new IllegalArgumentException("Argument \"itemId\" is marked as non-null but was passed a null value.");
      }
      __result.arguments.put("itemId", itemId);
    } else {
      throw new IllegalArgumentException("Required argument \"itemId\" is missing and does not have an android:defaultValue");
    }
    if (savedStateHandle.contains("itemCount")) {
      String itemCount;
      itemCount = savedStateHandle.get("itemCount");
      if (itemCount == null) {
        throw new IllegalArgumentException("Argument \"itemCount\" is marked as non-null but was passed a null value.");
      }
      __result.arguments.put("itemCount", itemCount);
    } else {
      throw new IllegalArgumentException("Required argument \"itemCount\" is missing and does not have an android:defaultValue");
    }
    return __result;
  }

  @SuppressWarnings("unchecked")
  @NonNull
  public String getItemId() {
    return (String) arguments.get("itemId");
  }

  @SuppressWarnings("unchecked")
  @NonNull
  public String getItemCount() {
    return (String) arguments.get("itemCount");
  }

  @SuppressWarnings("unchecked")
  @NonNull
  public Bundle toBundle() {
    Bundle __result = new Bundle();
    if (arguments.containsKey("itemId")) {
      String itemId = (String) arguments.get("itemId");
      __result.putString("itemId", itemId);
    }
    if (arguments.containsKey("itemCount")) {
      String itemCount = (String) arguments.get("itemCount");
      __result.putString("itemCount", itemCount);
    }
    return __result;
  }

  @SuppressWarnings("unchecked")
  @NonNull
  public SavedStateHandle toSavedStateHandle() {
    SavedStateHandle __result = new SavedStateHandle();
    if (arguments.containsKey("itemId")) {
      String itemId = (String) arguments.get("itemId");
      __result.set("itemId", itemId);
    }
    if (arguments.containsKey("itemCount")) {
      String itemCount = (String) arguments.get("itemCount");
      __result.set("itemCount", itemCount);
    }
    return __result;
  }

  @Override
  public boolean equals(Object object) {
    if (this == object) {
        return true;
    }
    if (object == null || getClass() != object.getClass()) {
        return false;
    }
    EditDataFragmentArgs that = (EditDataFragmentArgs) object;
    if (arguments.containsKey("itemId") != that.arguments.containsKey("itemId")) {
      return false;
    }
    if (getItemId() != null ? !getItemId().equals(that.getItemId()) : that.getItemId() != null) {
      return false;
    }
    if (arguments.containsKey("itemCount") != that.arguments.containsKey("itemCount")) {
      return false;
    }
    if (getItemCount() != null ? !getItemCount().equals(that.getItemCount()) : that.getItemCount() != null) {
      return false;
    }
    return true;
  }

  @Override
  public int hashCode() {
    int result = 1;
    result = 31 * result + (getItemId() != null ? getItemId().hashCode() : 0);
    result = 31 * result + (getItemCount() != null ? getItemCount().hashCode() : 0);
    return result;
  }

  @Override
  public String toString() {
    return "EditDataFragmentArgs{"
        + "itemId=" + getItemId()
        + ", itemCount=" + getItemCount()
        + "}";
  }

  public static final class Builder {
    private final HashMap arguments = new HashMap();

    @SuppressWarnings("unchecked")
    public Builder(@NonNull EditDataFragmentArgs original) {
      this.arguments.putAll(original.arguments);
    }

    @SuppressWarnings("unchecked")
    public Builder(@NonNull String itemId, @NonNull String itemCount) {
      if (itemId == null) {
        throw new IllegalArgumentException("Argument \"itemId\" is marked as non-null but was passed a null value.");
      }
      this.arguments.put("itemId", itemId);
      if (itemCount == null) {
        throw new IllegalArgumentException("Argument \"itemCount\" is marked as non-null but was passed a null value.");
      }
      this.arguments.put("itemCount", itemCount);
    }

    @NonNull
    public EditDataFragmentArgs build() {
      EditDataFragmentArgs result = new EditDataFragmentArgs(arguments);
      return result;
    }

    @NonNull
    @SuppressWarnings("unchecked")
    public Builder setItemId(@NonNull String itemId) {
      if (itemId == null) {
        throw new IllegalArgumentException("Argument \"itemId\" is marked as non-null but was passed a null value.");
      }
      this.arguments.put("itemId", itemId);
      return this;
    }

    @NonNull
    @SuppressWarnings("unchecked")
    public Builder setItemCount(@NonNull String itemCount) {
      if (itemCount == null) {
        throw new IllegalArgumentException("Argument \"itemCount\" is marked as non-null but was passed a null value.");
      }
      this.arguments.put("itemCount", itemCount);
      return this;
    }

    @SuppressWarnings({"unchecked","GetterOnBuilder"})
    @NonNull
    public String getItemId() {
      return (String) arguments.get("itemId");
    }

    @SuppressWarnings({"unchecked","GetterOnBuilder"})
    @NonNull
    public String getItemCount() {
      return (String) arguments.get("itemCount");
    }
  }
}

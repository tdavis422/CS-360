package com.example.projecttwo.ui.home;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.navigation.NavDirections;
import com.example.projecttwo.R;
import java.lang.IllegalArgumentException;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.lang.SuppressWarnings;
import java.util.HashMap;

public class HomeFragmentDirections {
  private HomeFragmentDirections() {
  }

  @NonNull
  public static ActionHomeToEdit actionHomeToEdit(@NonNull String itemId,
      @NonNull String itemCount) {
    return new ActionHomeToEdit(itemId, itemCount);
  }

  public static class ActionHomeToEdit implements NavDirections {
    private final HashMap arguments = new HashMap();

    @SuppressWarnings("unchecked")
    private ActionHomeToEdit(@NonNull String itemId, @NonNull String itemCount) {
      if (itemId == null) {
        throw new IllegalArgumentException("Argument \"itemId\" is marked as non-null but was passed a null value.");
      }
      this.arguments.put("itemId", itemId);
      if (itemCount == null) {
        throw new IllegalArgumentException("Argument \"itemCount\" is marked as non-null but was passed a null value.");
      }
      this.arguments.put("itemCount", itemCount);
    }

    @NonNull
    @SuppressWarnings("unchecked")
    public ActionHomeToEdit setItemId(@NonNull String itemId) {
      if (itemId == null) {
        throw new IllegalArgumentException("Argument \"itemId\" is marked as non-null but was passed a null value.");
      }
      this.arguments.put("itemId", itemId);
      return this;
    }

    @NonNull
    @SuppressWarnings("unchecked")
    public ActionHomeToEdit setItemCount(@NonNull String itemCount) {
      if (itemCount == null) {
        throw new IllegalArgumentException("Argument \"itemCount\" is marked as non-null but was passed a null value.");
      }
      this.arguments.put("itemCount", itemCount);
      return this;
    }

    @Override
    @SuppressWarnings("unchecked")
    @NonNull
    public Bundle getArguments() {
      Bundle __result = new Bundle();
      if (arguments.containsKey("itemId")) {
        String itemId = (String) arguments.get("itemId");
        __result.putString("itemId", itemId);
      }
      if (arguments.containsKey("itemCount")) {
        String itemCount = (String) arguments.get("itemCount");
        __result.putString("itemCount", itemCount);
      }
      return __result;
    }

    @Override
    public int getActionId() {
      return R.id.action_home_to_edit;
    }

    @SuppressWarnings("unchecked")
    @NonNull
    public String getItemId() {
      return (String) arguments.get("itemId");
    }

    @SuppressWarnings("unchecked")
    @NonNull
    public String getItemCount() {
      return (String) arguments.get("itemCount");
    }

    @Override
    public boolean equals(Object object) {
      if (this == object) {
          return true;
      }
      if (object == null || getClass() != object.getClass()) {
          return false;
      }
      ActionHomeToEdit that = (ActionHomeToEdit) object;
      if (arguments.containsKey("itemId") != that.arguments.containsKey("itemId")) {
        return false;
      }
      if (getItemId() != null ? !getItemId().equals(that.getItemId()) : that.getItemId() != null) {
        return false;
      }
      if (arguments.containsKey("itemCount") != that.arguments.containsKey("itemCount")) {
        return false;
      }
      if (getItemCount() != null ? !getItemCount().equals(that.getItemCount()) : that.getItemCount() != null) {
        return false;
      }
      if (getActionId() != that.getActionId()) {
        return false;
      }
      return true;
    }

    @Override
    public int hashCode() {
      int result = 1;
      result = 31 * result + (getItemId() != null ? getItemId().hashCode() : 0);
      result = 31 * result + (getItemCount() != null ? getItemCount().hashCode() : 0);
      result = 31 * result + getActionId();
      return result;
    }

    @Override
    public String toString() {
      return "ActionHomeToEdit(actionId=" + getActionId() + "){"
          + "itemId=" + getItemId()
          + ", itemCount=" + getItemCount()
          + "}";
    }
  }
}

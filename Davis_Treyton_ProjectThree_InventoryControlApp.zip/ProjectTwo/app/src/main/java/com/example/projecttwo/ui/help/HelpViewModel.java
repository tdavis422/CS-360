package com.example.projecttwo.ui.help;

import androidx.lifecycle.ViewModel;

public class HelpViewModel extends ViewModel {

    public HelpViewModel() { }

}
